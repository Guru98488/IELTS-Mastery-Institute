// Site-wide form validation
document.addEventListener('DOMContentLoaded', function(){
  const forms = Array.from(document.querySelectorAll('form'));
  forms.forEach(form => {
    form.setAttribute('novalidate', 'true');
    form.addEventListener('submit', function(e){
      let valid = validateForm(form);
      if(!valid){
        e.preventDefault();
        e.stopPropagation();
        const firstInvalid = form.querySelector('.input-error');
        if(firstInvalid) firstInvalid.focus();
      }
    });
    const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
    inputs.forEach(inp => {
      inp.addEventListener('input', () => validateField(inp));
      inp.addEventListener('blur', () => validateField(inp));
    });
  });

  function validateForm(form){
    let ok = true;
    const inputs = Array.from(form.querySelectorAll('input, textarea, select'));
    inputs.forEach(inp => {
      const res = validateField(inp);
      if(!res) ok = false;
    });
    return ok;
  }

  function validateField(field){
    if(field.disabled) return true;
    const type = field.getAttribute('type') || field.tagName.toLowerCase();
    let valid = true;
    let value = field.value.trim();

    if(field.hasAttribute('required') && value === ''){
      valid = false;
      showError(field, field.getAttribute('data-error') || 'This field is required');
      return false;
    }

    if(valid && value !== ''){
      if(type === 'email'){
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if(!re.test(value)) { valid = false; showError(field, 'Enter a valid email'); }
      } else if(type === 'tel'){
        const re = /^[0-9()+-\s]{7,20}$/;
        if(!re.test(value)) { valid = false; showError(field, 'Enter a valid phone number'); }
      } else if(field.hasAttribute('minlength')){
        const ml = parseInt(field.getAttribute('minlength'),10) || 0;
        if(value.length < ml){ valid = false; showError(field, `Enter at least ${ml} characters`); }
      } else if(field.hasAttribute('pattern')){
        try{
          const p = new RegExp(field.getAttribute('pattern'));
          if(!p.test(value)){ valid = false; showError(field, 'Invalid format'); }
        }catch(e){}
      }
    }

    if(valid){
      clearError(field);
      return true;
    }else{
      return false;
    }
  }

  function showError(field, message){
    field.classList.add('input-error');
    let id = field.getAttribute('aria-describedby');
    let msgEl = null;
    if(id) msgEl = document.getElementById(id);
    if(!msgEl){
      msgEl = field.parentElement ? field.parentElement.querySelector('.error-msg') : null;
    }
    if(!msgEl){
      msgEl = document.createElement('div');
      msgEl.className = 'error-msg';
      field.parentElement && field.parentElement.appendChild(msgEl);
    }
    msgEl.textContent = message;
    msgEl.classList.add('active');
  }

  function clearError(field){
    field.classList.remove('input-error');
    let id = field.getAttribute('aria-describedby');
    let msgEl = null;
    if(id) msgEl = document.getElementById(id);
    if(!msgEl) msgEl = field.parentElement ? field.parentElement.querySelector('.error-msg') : null;
    if(msgEl){ msgEl.classList.remove('active'); msgEl.textContent = ''; }
  }
});