import React from 'react'

const cards = [
  {title: 'Speaking Practice', desc: 'Live sessions with expert tutors.'},
  {title: 'Mock Tests', desc: 'Real exam environment with timings.'},
  {title: 'AI Band Score', desc: 'Get instant predicted band scores.'},
  {title: 'Personal Coaching', desc: 'One-on-one mentoring plans.'},
]

export default function Features(){
  return (
    <section className="py-12 bg-white">
      <div className="container">
        <h2 className="text-2xl font-semibold">What we offer</h2>
        <p className="mt-2 text-gray-600">Everything you need to succeed in IELTS.</p>
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((c, i) => (
            <div key={i} className="p-5 bg-gray-50 rounded-lg border">
              <div className="font-semibold">{c.title}</div>
              <p className="mt-2 text-sm text-gray-600">{c.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
