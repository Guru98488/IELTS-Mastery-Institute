import React from 'react'

const reviews = [
  {name: 'Rohit S.', text: 'Scored Band 8.0. The mock tests were very close to the real exam.'},
  {name: 'Anita P.', text: 'The speaking practice improved my confidence a lot.'},
  {name: 'Karan M.', text: 'AI feedback helped me fix repeating mistakes fast.'},
]

export default function Testimonials(){
  return (
    <section className="py-12">
      <div className="container">
        <h3 className="text-2xl font-semibold">Student Testimonials</h3>
        <div className="mt-6 grid md:grid-cols-3 gap-4">
          {reviews.map((r, i) => (
            <div key={i} className="p-4 bg-white rounded-lg shadow-sm border">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-semibold">{r.name.split(' ')[0][0]}</div>
                <div>
                  <div className="font-semibold">{r.name}</div>
                  <div className="text-sm text-gray-500">Student</div>
                </div>
              </div>
              <p className="mt-3 text-gray-600 text-sm">"{r.text}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
