import React, { useState } from 'react'

export default function Navbar(){
  const [open, setOpen] = useState(false)
  return (
    <header className="bg-white shadow-sm">
      <div className="container flex items-center justify-between py-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold">IA</div>
          <div className="font-semibold text-lg">IELTS Academy</div>
        </div>
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#" className="hover:text-indigo-600">Home</a>
          <a href="#" className="hover:text-indigo-600">Courses</a>
          <a href="#" className="hover:text-indigo-600">About</a>
          <a href="#" className="hover:text-indigo-600">Contact</a>
          <button className="ml-4 px-4 py-2 bg-indigo-600 text-white rounded-md">Get Started</button>
        </nav>

        <div className="md:hidden">
          <button onClick={() => setOpen(!open)} aria-label="Toggle menu" className="p-2">
            <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={open ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16M4 18h16'} />
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden bg-white border-t">
          <div className="container flex flex-col py-4 space-y-3">
            <a href="#" className="block">Home</a>
            <a href="#" className="block">Courses</a>
            <a href="#" className="block">About</a>
            <a href="#" className="block">Contact</a>
            <button className="w-full mt-2 px-4 py-2 bg-indigo-600 text-white rounded-md">Get Started</button>
          </div>
        </div>
      )}
    </header>
  )
}
