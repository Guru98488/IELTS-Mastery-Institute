import React from 'react'

export default function Footer(){
  return (
    <footer className="bg-gray-900 text-gray-200">
      <div className="container py-8 flex flex-col md:flex-row justify-between items-start gap-6">
        <div>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white font-bold">IA</div>
            <div className="font-semibold">IELTS Academy</div>
          </div>
          <p className="mt-3 text-sm text-gray-300 max-w-sm">Helping students reach their dream band score with expert coaching and practice.</p>
        </div>
        <div className="text-sm">
          <div className="font-semibold">Quick Links</div>
          <ul className="mt-2 space-y-1">
            <li><a href="#" className="hover:underline">Home</a></li>
            <li><a href="#" className="hover:underline">Courses</a></li>
            <li><a href="#" className="hover:underline">Contact</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-gray-700 text-center py-4 text-sm">© 2025 IELTS Academy. All rights reserved.</div>
    </footer>
  )
}
