import React from 'react'

export default function Hero(){
  return (
    <section className="py-16">
      <div className="container grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold leading-tight">Crack IELTS with Confidence</h1>
          <p className="mt-4 text-gray-600">Join 10,000+ students who improved their band scores with our expert coaching, mock tests, and AI-backed feedback.</p>
          <div className="mt-6 flex items-center gap-4">
            <a href="#" className="px-6 py-3 bg-indigo-600 text-white rounded-md shadow">Get Started</a>
            <a href="#" className="px-6 py-3 border rounded-md">View Courses</a>
          </div>
          <ul className="mt-6 grid grid-cols-2 gap-2 text-sm text-gray-600">
            <li>Live Speaking Practice</li>
            <li>Timed Mock Tests</li>
            <li>Personalized Feedback</li>
            <li>AI Band Predictor</li>
          </ul>
        </div>
        <div className="flex justify-center">
          <div className="w-full max-w-md bg-gradient-to-tr from-white to-indigo-50 rounded-xl p-6 shadow-md">
            <img src="/hero-illustration.png" alt="hero" className="w-full h-56 object-cover rounded-md" onError={(e)=>{e.target.style.display='none'}} />
            <div className="mt-4 text-center text-sm text-gray-500">Practice anywhere — desktop or mobile</div>
          </div>
        </div>
      </div>
    </section>
  )
}
